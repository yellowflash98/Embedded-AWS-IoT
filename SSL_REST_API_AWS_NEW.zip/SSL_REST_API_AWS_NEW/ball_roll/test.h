#ifndef TEST_H
#define TEST_H


#define	BLACK           0x0000 //include the color definitions again
#define	BLUE            0x001F
#define	GREEN           0x07E0
#define CYAN            0x07FF
#define	RED             0xF800
#define MAGENTA         0xF81F
#define YELLOW          0xFFE0
#define WHITE           0xFFFF

void delay(unsigned long ulCount); //all referenced functions must be initialized here.
void drawrandomcircle(unsigned char x, unsigned char y);
void eraserandomcircle(unsigned char x, unsigned char y);
void littleCircle(unsigned char x, unsigned char y);
void erasePrevCircle(unsigned char x, unsigned char y);
void drawFonts();
void helloWorld();
void HLines();
void VLines();
void testlines(unsigned int color);
void testfastlines(unsigned int color1, unsigned int color2);
void testdrawrects(unsigned int color);
void testfillcircles(unsigned char radius, unsigned int color);
void testfillrects(unsigned int color1, unsigned int color2);
void testdrawcircles(unsigned char radius, unsigned int color);
void testroundrects();
void testtriangles();
void lcdTestPattern();
void lcdTestPattern2();
#endif
