
/* These functions are based on the Arduino test program at
*  https://github.com/adafruit/Adafruit-SSD1351-library/blob/master/examples/test/test.ino
*
*  You can use these high-level routines to implement your
*  test program.
*/

// TODO Configure SPI port and use these libraries to implement
// an OLED test program. See SPI example program.


#include "Adafruit_GFX.h"
#include "Adafruit_SSD1351.h"
#include "test.h"
#include "glcdfont.h" //for font[] call

extern int cursor_x;
extern int cursor_y;

float p = 3.1415926;

// Color definitions
#define	BLACK           0x0000
#define	BLUE            0x001F
#define	GREEN           0x07E0
#define CYAN            0x07FF
#define	RED             0xF800
#define MAGENTA         0xF81F
#define YELLOW          0xFFE0
#define WHITE           0xFFFF

//*****************************************************************************
//  function delays 3*ulCount cycles
void delay(unsigned long ulCount){
	int i;

  do{
    ulCount--;
		for (i=0; i< 65535; i++) ;
	}while(ulCount);
}


//*****************************************************************************
void littleCircle(unsigned char x, unsigned char y){
    if(x >= 120){
        unsigned char radius = 5;
        unsigned int color = GREEN;
        fillCircle(x, y, radius, color);
    }
    if(x <= 6){
        unsigned char radius = 6;
        unsigned int color = BLUE;
        fillCircle(x, y, radius, color);
    }
    else{
        unsigned char radius = 4;
        unsigned int color = RED;
        fillCircle(x, y, radius, color);
    }

}

void drawrandomcircle(unsigned char x, unsigned char y){
    drawCircle(x, y, 7, WHITE);
}
void eraserandomcircle(unsigned char x, unsigned char y){
    drawCircle(x, y, 7, BLACK);
}
void erasePrevCircle(unsigned char x, unsigned char y){
    if(x >= 120){
            unsigned char radius = 5;
            unsigned int color = BLACK;
            fillCircle(x, y, radius, color);
        }
        if(x <= 6){
            unsigned char radius = 6;
            unsigned int color = BLACK;
            fillCircle(x, y, radius, color);
        }
        else{
            unsigned char radius = 4;
            unsigned int color = BLACK;
            fillCircle(x, y, radius, color);
        }

}

void drawFonts(){
    fillScreen(BLACK);
    int x = 0; //coordinate of printed characters will start at 0,0
    int y = 0;
    int i = 0;
    for (i = 0; i < 1275; i++){ //there are (261-6)255 rows, 5 columns, we need to loop through 255*5 times
        drawChar(x, y, font[i], WHITE, BLACK, 1); //drawChar is the perfect function for this.
        x = x + 6; //move to the 6th pixel on screen
        if( x >= 120){ //don't go out of bounds, instead go to the next row.
             x = 0;
             y = y + 10; //arbitrarily chosen at 10
        }
        delay(10);

    }
}

void helloWorld() { //use drawChar to write every character next to each other
    fillScreen(BLACK);
    drawChar(0, 80, 'H', RED, YELLOW, 3);
    drawChar(10, 80, 'e', RED, YELLOW, 3);
    drawChar(20, 80, 'l', RED, YELLOW, 3);
    drawChar(30, 80, 'l', RED, YELLOW, 3);
    drawChar(40, 80, 'o', RED, YELLOW, 3);
    drawChar(50, 80, '-', RED, YELLOW, 3);
    drawChar(60, 80, 'w', RED, YELLOW, 3);
    drawChar(70, 80, 'o', RED, YELLOW, 3);
    drawChar(80, 80, 'r', RED, YELLOW, 3);
    drawChar(90, 80, 'l', RED, YELLOW, 3);
    drawChar(100, 80, 'd', RED, YELLOW, 3);
    drawChar(110, 80, '!', RED, YELLOW, 3);
    delay(10);
}
void HLines(){ //use the built-in function drawFastHLine to draw horizontal lines for me.
    //set screen to black
    fillScreen(BLACK);
    int y;
    for(y = 0; y < 14; y++){  //Using testfastlines as inspiration, we create a for loop to create 14 individual lines for each color
       drawFastHLine(0, y, width()-1, BLACK); //Go through each color in order of appearance on the color definitions
       drawFastHLine(0, y + 14, width()-1, BLUE);
       drawFastHLine(0, y + (14*2), width()-1, GREEN);
       drawFastHLine(0, y + (14*3), width()-1, CYAN);
       drawFastHLine(0, y + (14*4), width()-1, RED);
       drawFastHLine(0, y + (14*5), width()-1, MAGENTA);
       drawFastHLine(0, y + (14*6), width()-1, YELLOW);
       drawFastHLine(0, y + (14*7), width()-1, WHITE);
       delay(10);
    }

}

void VLines(){ //repeat the same thing from HLines(), but this time use drawFastVLine and change x instead of y, use height instead of width.
    fillScreen(BLACK);
    int x;
    for(x = 0; x < 14; x++){
        drawFastVLine(x, 0, height()-1, BLACK);
       drawFastVLine(x+14, 0, height()-1, BLUE);
       drawFastVLine(x+(14*2), 0, height()-1, GREEN);
       drawFastVLine(x+(14*3), 0, height()-1, CYAN);
       drawFastVLine(x+(14*4), 0, height()-1, RED);
       drawFastVLine(x+(14*5), 0, height()-1, MAGENTA);
       drawFastVLine(x+(14*6), 0, height()-1, YELLOW);
       drawFastVLine(x+(14*7), 0, height()-1, WHITE);
       delay(10);
    }
}

void testfastlines(unsigned int color1, unsigned int color2) {
	unsigned int x;
	unsigned int y;

   fillScreen(BLACK);
   for (y=0; y < height()-1; y+=8) {
     drawFastHLine(0, y, width()-1, color1);
   }
	 delay(100);
   for (x=0; x < width()-1; x+=8) {
     drawFastVLine(x, 0, height()-1, color2);
   }
	 delay(100);
}




//*****************************************************************************

void testdrawrects(unsigned int color) {
	unsigned int x;

 fillScreen(BLACK);
 for (x=0; x < height()-1; x+=6) {
   drawRect((width()-1)/2 -x/2, (height()-1)/2 -x/2 , x, x, color);
	 delay(10);
 }
}

//*****************************************************************************

void testfillrects(unsigned int color1, unsigned int color2) {

	unsigned char x;

 fillScreen(BLACK);
 for (x=height()-1; x > 6; x-=6) {
   fillRect((width()-1)/2 -x/2, (height()-1)/2 -x/2 , x, x, color1);
   drawRect((width()-1)/2 -x/2, (height()-1)/2 -x/2 , x, x, color2);
	 delay(10);
 }
}

//*****************************************************************************

void testfillcircles(unsigned char radius, unsigned int color) {
	unsigned char x;
	unsigned char y;

  for (x=radius; x < width()-1; x+=radius*2) {
    for (y=radius; y < height()-1; y+=radius*2) {
      fillCircle(x, y, radius, color);
			delay(10);
    }
  }
}

//*****************************************************************************

void testdrawcircles(unsigned char radius, unsigned int color) {
	unsigned char x;
	unsigned char y;

  for (x=0; x < width()-1+radius; x+=radius*2) {
    for (y=0; y < height()-1+radius; y+=radius*2) {
      drawCircle(x, y, radius, color);
			delay(10);
    }
  }
}

//*****************************************************************************

void testtriangles() {
  int color = 0xF800;
  int t;
  int w = width()/2;
  int x = height()-1;
  int y = 0;
  int z = width()-1;

  fillScreen(BLACK);
  for(t = 0 ; t <= 15; t+=1) {
    drawTriangle(w, y, y, x, z, x, color);
    x-=4;
    y+=4;
    z-=4;
    color+=100;
		delay(10);
  }
}

//*****************************************************************************

void testroundrects() {
  int color = 100;

	int i;
  int x = 0;
  int y = 0;
  int w = width();
  int h = height();

  fillScreen(BLACK);

  for(i = 0 ; i <= 24; i++) {
    drawRoundRect(x, y, w, h, 5, color);
    x+=2;
    y+=3;
    w-=4;
    h-=6;
    color+=1100;
  }
}

//*****************************************************************************
void testlines(unsigned int color) {
	unsigned int x;
	unsigned int y;

   fillScreen(BLACK);
   for (x=0; x < width()-1; x+=6) {
     drawLine(0, 0, x, height()-1, color);
   }
	 delay(10);
   for (y=0; y < height()-1; y+=6) {
     drawLine(0, 0, width()-1, y, color);
   }
	 delay(100);

   fillScreen(BLACK);
   for (x=0; x < width()-1; x+=6) {
     drawLine(width()-1, 0, x, height()-1, color);
   }
	 delay(100);
   for (y=0; y < height()-1; y+=6) {
     drawLine(width()-1, 0, 0, y, color);
   }
	 delay(100);

   fillScreen(BLACK);
   for (x=0; x < width()-1; x+=6) {
     drawLine(0, height()-1, x, 0, color);
   }
	 delay(100);
   for (y=0; y < height()-1; y+=6) {
     drawLine(0, height()-1, width()-1, y, color);
   }
	 delay(100);

   fillScreen(BLACK);
   for (x=0; x < width()-1; x+=6) {
     drawLine(width()-1, height()-1, x, 0, color);
   }
	 delay(100);
   for (y=0; y < height()-1; y+=6) {
     drawLine(width()-1, height()-1, 0, y, color);
   }
	 delay(100);

}

//*****************************************************************************

void lcdTestPattern(void)
{
  unsigned int i,j;
  goTo(0, 0);

  for(i=0;i<128;i++)
  {
    for(j=0;j<128;j++)
    {
      if(i<16){writeData(RED>>8); writeData((unsigned char) RED);}
      else if(i<32) {writeData(YELLOW>>8);writeData((unsigned char) YELLOW);}
      else if(i<48){writeData(GREEN>>8);writeData((unsigned char) GREEN);}
      else if(i<64){writeData(CYAN>>8);writeData((unsigned char) CYAN);}
      else if(i<80){writeData(BLUE>>8);writeData((unsigned char) BLUE);}
      else if(i<96){writeData(MAGENTA>>8);writeData((unsigned char) MAGENTA);}
      else if(i<112){writeData(BLACK>>8);writeData((unsigned char) BLACK);}
      else {writeData(WHITE>>8); writeData((unsigned char) WHITE);}
    }
  }
}
/**************************************************************************/
void lcdTestPattern2(void)
{
  unsigned int i,j;
  goTo(0, 0);

  for(i=0;i<128;i++)
  {
    for(j=0;j<128;j++)
    {
      if(j<16){writeData(RED>>8); writeData((unsigned char) RED);}
      else if(j<32) {writeData(YELLOW>>8);writeData((unsigned char) YELLOW);}
      else if(j<48){writeData(GREEN>>8);writeData((unsigned char) GREEN);}
      else if(j<64){writeData(CYAN>>8);writeData((unsigned char) CYAN);}
      else if(j<80){writeData(BLUE>>8);writeData((unsigned char) BLUE);}
      else if(j<96){writeData(MAGENTA>>8);writeData((unsigned char) MAGENTA);}
      else if(j<112){writeData(BLACK>>8);writeData((unsigned char) BLACK);}
      else {writeData(WHITE>>8);writeData((unsigned char) WHITE);}
    }
  }
}

/**************************************************************************/

